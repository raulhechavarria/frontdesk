/**
 * Service layer beans.
 */
package io.github.jhipster.application.service;
