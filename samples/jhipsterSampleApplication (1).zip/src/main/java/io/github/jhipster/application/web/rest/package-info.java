/**
 * Spring MVC REST controllers.
 */
package io.github.jhipster.application.web.rest;
